+-------------------------------+
| INSTALLING AND USING LABELARY |
+-------------------------------+

1. Install Java
2. Verify Java Installation
3. Running
  3.a Private API (Non-Docker)
  3.b Private API (Docker)
  3.c Command Line File Converter
  3.d Embedded


1. Install Java

    Before using Labelary, make sure that you have the latest version of OpenJDK 11 installed.
    OpenJDK 11 can be downloaded from the AdoptOpenJDK website at:

    https://adoptopenjdk.net/upstream.html

    It is strongly recommended that you use the OpenJDK, rather than the Oracle JDK, because the
    Oracle JDK requires a commercial license for production use and is not as extensively tested
    with Labelary as the OpenJDK.

    NOTE: THIS STEP IS NOT NECESSARY IF YOU PLAN TO USE DOCKER (SECTION 3.b BELOW).

2. Verify Java Installation

    Once OpenJDK 11 is installed, verify that everything is set up correctly by running "java -version":

    > java -version
	openjdk version "11.0.4" 2019-07-16
	OpenJDK Runtime Environment 18.9 (build 11.0.4+11)
	OpenJDK 64-Bit Server VM 18.9 (build 11.0.4+11, mixed mode)

    NOTE: THIS STEP IS NOT NECESSARY IF YOU PLAN TO USE DOCKER (SECTION 3.b BELOW).

3. Running

    You have a couple of options, depending on how you plan to use Labelary:

    3.a Private API (Non-Docker)

        3.a.i Unzip the provided zip file into a new directory:

            > jar xf labelary-2.3.0.zip

        3.a.ii Start the server in headless mode (-Djava.awt.headless=true), with the appropriate
            license path (-Dlabelary.license.path=/path/to/labelary.license), max memory (-Xmx) and
            min memory (-Xms), on port 8080:

            > cd labelary-2.3.0
            > java -cp "./lib/*" -Xms256m -Xmx2048m -Djava.awt.headless=true -Dlabelary.license.path=/path/to/labelary.license -Dlabelary.port=8080 com.labelary.main.HttpServer

            If you are deploying to a Windows server and would like to run Labelary as a Windows
            service, you can use the "install-windows-service.bat" batch file in the "bin" directory.
            Before installing the Labelary service be sure to install Java, set the JAVA_HOME
            environment variable to your root Java runtime directory, and copy your Labelary license
            file to the Labelary "bin" directory. By default the service will run on port 8080 and use
            up to 2 GB of memory, but this can be adjusted by editing the "install-windows-service.bat"
            batch file before running it. For more options and information, see the "prunsrv"
            documentation online at:

            http://commons.apache.org/proper/commons-daemon/procrun.html#Procrun_service_application

        3.a.iii Verify that Labelary is running and serving requests by checking the /version endpoint. If you
            are not running Labelary on the local machine, replace "localhost" below with the actual server
            hostname. If Labelary is listening on a port other than port 80, adjust the port number as well:

            > curl http://localhost/version

        3.a.iv Verify that the license information at the /license endpoint looks correct. Again, if you
            are not running Labelary on the local machine, replace "localhost" below with the actual server
            hostname. If Labelary is listening on a port other than port 80, adjust the port number as well:

            > curl http://localhost/license

    3.b Private API (Docker)

        3.b.i The Labelary Docker image is provided in a separate tar file. Use the "docker load" command to load the Docker image:

            > docker load --input labelary-2.3.0.tar

        3.b.ii Verify that the Docker image was loaded correctly and is available to run:

            > docker images labelary

        3.b.iii Once the Docker image has been loaded, it can be run using the standard Docker commands. The image
            serves HTTP requests on port 80. The JAVA_TOOL_OPTIONS environment variable can be used to send custom
            Java command line options (see example below). The LABELARY_LICENSE environment variable *must* be used
            to specify the Labelary license; the content of this environment variable should be the content of your
            Labelary license file, with the XML prolog (the first two lines) removed, with the "version" attribute
            removed from the root node, and with all newlines removed:

            > docker run -it -p 80:80 -e "LABELARY_LICENSE=<plist><dict>...</dict></plist>" -e "JAVA_TOOL_OPTIONS=-Xmx2g" labelary:latest

        3.b.iv Verify that the container is running and serving requests by checking the /version endpoint. If you
            are not running the container on the local machine, replace "localhost" below with the actual server
            hostname. If Docker is mapping to a port other than port 80, adjust the port number as well:

            > curl http://localhost/version

        3.b.v Verify that the license information at the /license endpoint looks correct. Again, if you
            are not running the container on the local machine, replace "localhost" below with the actual server
            hostname. If Docker is mapping to a port other than port 80, adjust the port number as well:

            > curl http://localhost/license

    3.c Command Line File Converter

        3.c.i Unzip the provided zip file into a new directory:

            > jar xf labelary-2.3.0.zip

        3.c.ii Start the command line file converter in headless mode (-Djava.awt.headless=true),
            with the appropriate license path (-Dlabelary.license.path=/path/to/labelary.license),
            max memory (-Xmx) and min memory (-Xms). The following additional parameters are available:

                -density (required)
                    Printer print density, in dots per mm (one of 6, 8, 12 or 24)
                -width (required)
                    Label width, in inches
                -height (required)
                    Label height, in inches
                -input (required)
                    Input ZPL file
                -output (required)
                    Output image or PDF file
                -index (optional)
                    Index of a specific label to render, if not all are needed (base 1)
                -quality (optional)
                    Print quality (either Grayscale or Bitonal, default is Grayscale)
                -rotation (optional)
                    Label rotation, in degrees (one of 0, 90, 180 or 270)
                -pageSize (optional)
                    PDF page size (one of A4, A5, A6 or Letter)
                -pageOrientation (optional)
                    PDF page orientation (either Portrait or Landscape)
                -pageLayout (optional)
                    PDF page layout (<cols>x<rows>, e.g. 1x2, 2x2, 1x3, etc.)
                -pageAlign (optional)
                    PDF page layout alignment (Left, Right, Center or Justify)
                -pageVerticalAlign (optional)
                    PDF page layout vertical alignment (Top, Bottom, Center or Justify)
                -checkBeforeWrite (optional)
                    Try to avoid unnecessarily overwriting output files
                -linter (optional)
                    Log linter warnings generated while parsing the ZPL
                -help
                    Prints the help message

            For example, to convert the "label.zpl" file to the PNG file "label.png" simulating a 12dpmm printer using 4x6 inch labels:

            > cd labelary-2.3.0
            > java -cp "./lib/*" -Xms64m -Xmx512m -Djava.awt.headless=true -Dlabelary.license.path=/path/to/labelary.license com.labelary.main.FileConverter -density 12 -width 4 -height 6 -input label.zpl -output label.png

            You can also convert to PDF by using an output file name with the ".pdf" extension:

            > cd labelary-2.3.0
            > java -cp "./lib/*" -Xms64m -Xmx512m -Djava.awt.headless=true -Dlabelary.license.path=/path/to/labelary.license com.labelary.main.FileConverter -density 12 -width 4 -height 6 -input label.zpl -output label.pdf

    3.d Embedded

        To embed Labelary in your Java or JVM application, add the JAR files in the lib directory to your
        classpath. In your code, create a new Printer and then use it to render your labels to images:

            String zpl = "^xa^cfa,50^fo100,100^fdHello World^fs^xz";
            Printer printer = new Printer(PrintDensity.DENSITY_8_DPMM, PrintQuality.GRAYSCALE, 4, 6);
            List< BufferedImage > labels = printer.render(zpl, new ImageWriter());

            for (int i = 0; i < labels.size(); i++) {
                BufferedImage label = labels.get(i);
                ImageIO.write(label, "png", new File("label-" + i + ".png"));
            }

        You may also generate a PDF file instead of images:

            String zpl = "^xa^cfa,50^fo100,100^fdHello World^fs^xz";
            Printer printer = new Printer(PrintDensity.DENSITY_8_DPMM, PrintQuality.GRAYSCALE, 4, 6);
            byte[] pdf = printer.render(zpl, new VectorPdfWriter());

        In order to configure the Labelary license in embedded mode, you can start your application using the same
        "labelary.license.path" system property used in sections 3.a and 3.b. However, if you'd rather embed the
        license file itself within your application and avoid the system property, you can also add the license
        file directly to your classpath. If you do this, the file must be in the root (not in a package), and it
        must be named "labelary.license".

        Please note the licensing implications of embedding Labelary in your own application, especially if you are
        not using a VAR (value-added reseller) license: because Labelary is licensed per device (where a device is
        usually, but not always, a server), your system will implicitly only be deployable on the number of devices
        for which you have purchased a Labelary license.
